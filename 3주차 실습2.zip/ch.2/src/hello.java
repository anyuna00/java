
public class hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1 = ("Hello World!");
		String s2 = ("I'm a new Java programmer!");
		
		System.out.println(s1 + "\n" + s2);
		
		for(int i = 0; i<5; i++) {
			System.out.println("i�� ����:" + i);
		}

	}

}
